export interface IOrder {
  categoryId: number | null
}
