export { default as UiLoader } from './Loader.vue'
export { default as SvgIcon } from './SvgIcon.vue'
